function plot(acq, cfg, varargin)
% Placeholder plot function for a McsCmosLinkedDataSource object
%
% function plot(acq, cfg, varargin)
%
% This function is empty at the moment
    
end